from .pdf_text import *

__doc__ = pdf_text.__doc__
if hasattr(pdf_text, "__all__"):
    __all__ = pdf_text.__all__