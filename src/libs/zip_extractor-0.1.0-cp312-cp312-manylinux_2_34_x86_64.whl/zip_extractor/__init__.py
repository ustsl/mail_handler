from .zip_extractor import *

__doc__ = zip_extractor.__doc__
if hasattr(zip_extractor, "__all__"):
    __all__ = zip_extractor.__all__